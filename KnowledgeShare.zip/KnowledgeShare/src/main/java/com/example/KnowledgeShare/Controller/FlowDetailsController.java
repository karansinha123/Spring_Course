package com.example.KnowledgeShare.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.multipart.MultipartFile;
import com.example.KnowledgeShare.Service.MainService;
import com.example.KnowledgeShare.Service.SuccessService;
import com.example.KnowledgeShare.Service.FailureService;
import com.example.KnowledgeShare.Service.MailService;

@Controller
public class FlowDetailsController 
{
	@Autowired
    MailService docservice1;
		
		@Autowired
		MainService docservice2;
		@Autowired
		SuccessService docservice3;
		@Autowired
		FailureService docservice4;
	   	
	
	 @RequestMapping("/add")
	  public String addFlow() {
		  return "addFlow";
	  }

	 @RequestMapping("/dashboard")
	  public String dashboardFlow() {
		  return "dashboard";
	  }

@PostMapping("/uploadFiles")
	public String uploadMultipleFiles(@RequestParam String logenable,@RequestParam String reqlogs,@RequestParam String lasterrorfaced,@RequestParam String flowname,@RequestParam("uploadmail") MultipartFile[] files,@RequestParam("uploadsuccesslogs") MultipartFile[] success,@RequestParam("uploadfailurelogs") MultipartFile[] uploadfailurelogs)
	{
		System.out.println("mail log called ");
		for (MultipartFile file:files) {
			docservice1.saveFile(flowname, file);
		}
		System.out.println("success log called ");
		for (MultipartFile file:success) {
			docservice3.saveFile(flowname, file);
		}
		System.out.println("failure log called ");
		for (MultipartFile file:uploadfailurelogs) {
			docservice4.saveFile(flowname, file);
		}
		
		System.out.println("half completed");
		docservice2.saveFile(flowname,logenable,reqlogs,lasterrorfaced);
		System.out.println("completed");
	        
					return "redirect:/dashboard";
	}
}
