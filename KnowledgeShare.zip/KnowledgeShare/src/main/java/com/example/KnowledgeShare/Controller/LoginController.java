package com.example.KnowledgeShare.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.KnowledgeShare.Model.Login;
import com.example.KnowledgeShare.Service.LoginService;
@Controller
public class LoginController 
{
	@Autowired
	LoginService service;
	
  @GetMapping("/login")
  public String loginpage() {
	  System.out.println("hello loginpage");
	  return "login";
  }
 
  @PostMapping("/login")
  public String postlogin(Login l,Model m ) {
	  System.out.println("hiii "+l.getSoeid());
	  if(service.validateUser(l)) {    // validating correct user or not.
		   return "dashboard"; //(I have to check if user validation is successful.... then how to chnage request from
		   									// /login to /userdashboard
	  }
	  else
	  {
		  m.addAttribute("message","Invalid Credential");
		  return "login";
	  }
	 
  }
  
 
}
