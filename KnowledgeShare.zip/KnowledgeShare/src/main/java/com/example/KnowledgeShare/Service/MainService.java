package com.example.KnowledgeShare.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.KnowledgeShare.DAO.MainDao;
import com.example.KnowledgeShare.Model.Main;
import com.example.KnowledgeShare.Repo.MainRepository;


@Service
public class MainService 
{
	

	@Autowired
	MainDao maindao;;
	
	public Main saveFile(String flowname,String logenable,String reqlogs,String lasterrorfaced) 
	{
		return maindao.saveFile(flowname, logenable, reqlogs, lasterrorfaced);
	}

}
