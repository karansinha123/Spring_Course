package com.example.KnowledgeShare.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.KnowledgeShare.DAO.SuccessDao;
import com.example.KnowledgeShare.Model.SuccessLog;
import com.example.KnowledgeShare.Repo.SuccessRepository;


@Service
public class SuccessService 
{
@Autowired
	SuccessDao successdao;

	public SuccessLog saveFile(String flowname,MultipartFile file) 
	{
		return successdao.saveFile(flowname, file);
		
	}
	

}
