package com.example.KnowledgeShare.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "maintable")
public class Main {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String flowname;
	private String logenable;
	private String reqlogs;
	private String lasterrorfaced;

public Main() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Main(String flowname, String logenable, String reqlogs, String lasterrorfaced) {
	super();
	this.flowname = flowname;
	this.logenable = logenable;
	this.reqlogs = reqlogs;
	this.lasterrorfaced = lasterrorfaced;
}
	


	public String getLogenable() {
		return logenable;
	}


	public void setLogenable(String logenable) {
		this.logenable = logenable;
	}


	public String getReqlogs() {
		return reqlogs;
	}


	public void setReqlogs(String reqlogs) {
		this.reqlogs = reqlogs;
	}


	public String getLasterrorfaced() {
		return lasterrorfaced;
	}


	public void setLasterrorfaced(String lasterrorfaced) {
		this.lasterrorfaced = lasterrorfaced;
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	public String getFlowname() {
		return flowname;
	}

	public void setFlowname(String flowname) {
		this.flowname = flowname;
	}

}

