package com.example.KnowledgeShare.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.KnowledgeShare.Model.Login;
import com.example.KnowledgeShare.Repo.RegistrationRepo;

@Repository
public class LoginDao {
	@Autowired
	RegistrationRepo repo;

	public boolean retrieveUser(Login l) {

		if (repo.existsById(l.getSoeid())) {
			System.out.println("Yes existed: ");
			return true;
		} else {
			System.out.println("Not existed :");
			return false;
		}

	}
}
