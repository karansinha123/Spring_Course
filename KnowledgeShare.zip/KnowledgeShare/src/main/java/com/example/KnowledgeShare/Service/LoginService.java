package com.example.KnowledgeShare.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.KnowledgeShare.DAO.LoginDao;
import com.example.KnowledgeShare.Model.Login;

@Service
public class LoginService
{
	@Autowired
	LoginDao dao;

	public boolean validateUser(Login l) 
	{
	return dao.retrieveUser(l);
	
		
	}
	
}
