package com.example.KnowledgeShare.Repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.KnowledgeShare.Model.Registration;


public interface RegistrationRepo extends JpaRepository<Registration,String> 
{
	/* You dont have to do anything else */
	/*List<Registration>  findByUsername(String username);
		
	@Query("from Registration where ccsid=:ccsid")	
	Registration isCCSIdExist(@Param("ccsid")int ccsid);*/
	
	/*
	 * Write sql for fetching password  and call in LOgin DAO together with existID
	 */
	
}


