package com.example.KnowledgeShare.Model;
import org.springframework.stereotype.Component;

@Component
public class Login
{
	private int id;
	private String soeid;
	private String password;
	
	
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Login(int id, String soeid, String password) {
		super();
		this.id = id;
		this.soeid = soeid;
		this.password = password;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getSoeid() {
		return soeid;
	}


	public void setSoeid(String soeid) {
		this.soeid = soeid;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "Login [id=" + id + ", soeid=" + soeid + ", password=" + password + "]";
	}

}

