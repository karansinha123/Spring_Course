package com.example.KnowledgeShare.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.KnowledgeShare.DAO.FailureDao;
import com.example.KnowledgeShare.Model.FailureLog;
import com.example.KnowledgeShare.Repo.FailureRepository;


@Service
public class FailureService 
{
	

	@Autowired
	FailureDao failuredao;

	public FailureLog saveFile(String flowname,MultipartFile file) 
	{
		return failuredao.saveFile(flowname, file);
		
	}
	

}
