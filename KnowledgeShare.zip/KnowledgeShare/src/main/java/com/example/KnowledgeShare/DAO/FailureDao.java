package com.example.KnowledgeShare.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.example.KnowledgeShare.Model.FailureLog;
import com.example.KnowledgeShare.Repo.FailureRepository;

@Repository
public class FailureDao 
{
	@Autowired
	FailureRepository docrepository4;
	
	public FailureLog saveFile(String flowname,MultipartFile file) 
	{
		System.out.println("failure Service method called");
		String docname=file.getOriginalFilename();
		try {
			FailureLog reg=new FailureLog(flowname,docname,file.getContentType());
			System.out.println("data saved to db for failure");
			return docrepository4.save(reg);
		  }
		catch(Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
}
