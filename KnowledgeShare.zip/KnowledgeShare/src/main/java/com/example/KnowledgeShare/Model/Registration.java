package com.example.KnowledgeShare.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "registration")
public class Registration 
{
	@Id
  private String soeid;
  private String fname;
  private String lname;
  private String pnumber;
  private String password;

  @Transient
  private  String confirmpassword;
  
public Registration() {
	super();
	// TODO Auto-generated constructor stub
}

public Registration(String soeid, String fname, String lname, String pnumber, String password, String confirmpassword) {
	super();
	this.soeid = soeid;
	this.fname = fname;
	this.lname = lname;
	this.pnumber = pnumber;
	this.password = password;
	this.confirmpassword = confirmpassword;
}

public String getSoeid() {
	return soeid;
}

public void setSoeid(String soeid) {
	this.soeid = soeid;
}

public String getFname() {
	return fname;
}

public void setFname(String fname) {
	this.fname = fname;
}

public String getLname() {
	return lname;
}

public void setLname(String lname) {
	this.lname = lname;
}

public String getPnumber() {
	return pnumber;
}

public void setPnumber(String pnumber) {
	this.pnumber = pnumber;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getConfirmpassword() {
	return confirmpassword;
}

public void setConfirmpassword(String confirmpassword) {
	this.confirmpassword = confirmpassword;
}

@Override
public String toString() {
	return "Registration [soeid=" + soeid + ", fname=" + fname + ", lname=" + lname + ", pnumber=" + pnumber
			+ ", password=" + password + ", confirmpassword=" + confirmpassword + "]";
}


}
