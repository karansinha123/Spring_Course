package com.example.KnowledgeShare.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.example.KnowledgeShare.Model.SuccessLog;
import com.example.KnowledgeShare.Repo.SuccessRepository;

@Repository
public class SuccessDao 
{
@Autowired
SuccessRepository docrepository3;

public SuccessLog saveFile(String flowname,MultipartFile file) 
{
	System.out.println("Success Service method called");
	String docname=file.getOriginalFilename();
	try {
		SuccessLog reg=new SuccessLog(flowname,docname,file.getContentType());
		System.out.println("data saved to db for success");
		return docrepository3.save(reg);
	  }
	catch(Exception e) {
		e.printStackTrace();
	}
	return null;
	
}
}
