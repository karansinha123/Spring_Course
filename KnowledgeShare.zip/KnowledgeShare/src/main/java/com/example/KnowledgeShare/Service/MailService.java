package com.example.KnowledgeShare.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.KnowledgeShare.DAO.MailDao;
import com.example.KnowledgeShare.Model.Mail;
import com.example.KnowledgeShare.Repo.MailRepository;

@Service
public class MailService 
{

	@Autowired
	MailDao maildao;
	
	public Mail saveFile(String flowname,MultipartFile file) 
	{
		return maildao.saveFile(flowname, file);
	}
	
}
