package com.example.KnowledgeShare.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.example.KnowledgeShare.Model.Mail;
import com.example.KnowledgeShare.Repo.MailRepository;

@Repository
public class MailDao {
	
	@Autowired
	MailRepository docrepository;
	
	public Mail saveFile(String flowname,MultipartFile file) 
	{
		System.out.println("mail Service method called");
		String docname=file.getOriginalFilename();
		try {
			Mail reg=new Mail(flowname,docname,file.getContentType());
			System.out.println("data saved to db for mail");
			return docrepository.save(reg);
		  }
		catch(Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}

}
