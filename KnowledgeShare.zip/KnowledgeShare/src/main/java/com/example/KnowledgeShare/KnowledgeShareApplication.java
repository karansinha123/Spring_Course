package com.example.KnowledgeShare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KnowledgeShareApplication {

	public static void main(String[] args) {
		SpringApplication.run(KnowledgeShareApplication.class, args);
		System.out.println("hii");
	}

}
