package com.example.KnowledgeShare.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.KnowledgeShare.Model.Main;
import com.example.KnowledgeShare.Repo.MainRepository;

@Repository
public class MainDao
{
@Autowired
	MainRepository docrepository2;
	
	public Main saveFile(String flowname,String logenable,String reqlogs,String lasterrorfaced) 
	{
		System.out.println("Service method called");
		try {
			Main reg=new Main(flowname,logenable,reqlogs,lasterrorfaced);// It will give file data
			System.out.println("data saved to db");
			return docrepository2.save(reg);
		  }
		catch(Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}

}
