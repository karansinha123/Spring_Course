package com.example.KnowledgeShare.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.KnowledgeShare.DAO.RegistrationDao;
import com.example.KnowledgeShare.Model.Registration;

@Service
public class RegistrationService
{
	@Autowired
	RegistrationDao regUser;
	public void regdata(Registration r) 
	{
		System.out.println("Called Service Layer:");
			regUser.addUser(r);	
    }
}
