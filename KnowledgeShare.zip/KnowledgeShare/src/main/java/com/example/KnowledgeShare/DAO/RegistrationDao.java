package com.example.KnowledgeShare.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.KnowledgeShare.Model.Registration;
import com.example.KnowledgeShare.Repo.RegistrationRepo;

@Repository
public class RegistrationDao 
{
	@Autowired
	RegistrationRepo repo;
	
  public void addUser(Registration r) 
  {
	  System.out.println("Called DAO Layer");
	repo.save(r);  
  }
}
