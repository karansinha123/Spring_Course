package com.example.KnowledgeShare.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.KnowledgeShare.Model.Main;

public interface MainRepository extends JpaRepository<Main,Integer> 
{

}
