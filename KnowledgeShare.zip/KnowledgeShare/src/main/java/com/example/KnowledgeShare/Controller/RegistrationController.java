package com.example.KnowledgeShare.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.KnowledgeShare.Model.Login;
import com.example.KnowledgeShare.Model.Registration;
import com.example.KnowledgeShare.Repo.RegistrationRepo;
import com.example.KnowledgeShare.Service.RegistrationService;
@Controller
public class RegistrationController 
{
	@Autowired
	RegistrationService regservice;
	
	
  @GetMapping("/registration")
  public String registrationpage() {
	  System.out.println("hello registration page");
	  return "registration";
  }
  @PostMapping("/registration")
  public String postregistration(Registration r) {
	  regservice.regdata(r);
	  return "login";
  }
}
